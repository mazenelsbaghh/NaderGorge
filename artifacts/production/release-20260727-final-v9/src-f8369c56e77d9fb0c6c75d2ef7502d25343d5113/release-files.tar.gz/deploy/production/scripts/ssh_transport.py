#!/usr/bin/env python3
"""Strict SSH transport for production cluster commands."""

from __future__ import annotations

import os
import shlex
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Sequence


class SshTransportError(RuntimeError):
    pass


@dataclass(frozen=True)
class SshTarget:
    node_id: str
    address: str
    user: str


class StrictSshTransport:
    def __init__(self, known_hosts: Path, identity_file: Path, connect_timeout_seconds: int = 10):
        self.known_hosts = known_hosts.expanduser().resolve()
        self.identity_file = identity_file.expanduser().resolve()
        self.connect_timeout_seconds = connect_timeout_seconds
        for label, path in (("known_hosts", self.known_hosts), ("identity_file", self.identity_file)):
            if not path.is_file():
                raise SshTransportError(f"{label} does not exist: {path}")
        mode = self.identity_file.stat().st_mode & 0o777
        if mode & 0o077:
            raise SshTransportError("identity_file permissions must not allow group/other access")

    def base_args(self) -> list[str]:
        return [
            "ssh",
            "-o", "BatchMode=yes",
            "-o", "IdentitiesOnly=yes",
            "-o", "StrictHostKeyChecking=yes",
            "-o", f"UserKnownHostsFile={self.known_hosts}",
            "-o", f"ConnectTimeout={self.connect_timeout_seconds}",
            "-i", str(self.identity_file),
        ]

    def run(
        self,
        target: SshTarget,
        remote_argv: Sequence[str],
        *,
        timeout_seconds: int = 60,
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        if not remote_argv:
            raise SshTransportError("remote command must not be empty")
        remote_command = shlex.join(list(remote_argv))
        completed = subprocess.run(
            [*self.base_args(), f"{target.user}@{target.address}", "--", remote_command],
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
            env={**os.environ, "LC_ALL": "C"},
        )
        if check and completed.returncode != 0:
            stderr = completed.stderr.strip() or "remote command failed"
            raise SshTransportError(f"{target.node_id}: {stderr}")
        return completed

    def copy(
        self,
        target: SshTarget,
        source: Path,
        destination: str,
        *,
        timeout_seconds: int = 60,
    ) -> None:
        if not source.is_file():
            raise SshTransportError(f"copy source does not exist: {source}")
        completed = subprocess.run(
            [
                "scp",
                "-o", "BatchMode=yes",
                "-o", "IdentitiesOnly=yes",
                "-o", "StrictHostKeyChecking=yes",
                "-o", f"UserKnownHostsFile={self.known_hosts}",
                "-o", f"ConnectTimeout={self.connect_timeout_seconds}",
                "-i", str(self.identity_file),
                str(source),
                f"{target.user}@{target.address}:{destination}",
            ],
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
            env={**os.environ, "LC_ALL": "C"},
        )
        if completed.returncode != 0:
            raise SshTransportError(
                f"{target.node_id}: {completed.stderr.strip() or 'secure copy failed'}"
            )

    def fetch(
        self,
        target: SshTarget,
        source: str,
        destination: Path,
        *,
        timeout_seconds: int = 60,
        max_bytes: int = 1024 * 1024,
    ) -> int:
        """Fetch one bounded regular file without overwriting a local path."""
        remote = PurePosixPath(source)
        if (
            not source
            or not remote.is_absolute()
            or remote.as_posix() != source
            or any(part in {"", ".", ".."} for part in remote.parts)
            or any(character not in "abcdefghijklmnopqrstuvwxyz"
                   "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/._-"
                   for character in source)
        ):
            raise SshTransportError("fetch source must be a normalized absolute path")
        if not isinstance(max_bytes, int) or isinstance(max_bytes, bool) or max_bytes <= 0:
            raise SshTransportError("fetch max_bytes must be a positive integer")

        requested = destination.expanduser()
        if requested.is_symlink() or requested.exists():
            raise SshTransportError("fetch destination must not exist or be a symlink")
        parent = requested.parent.resolve()
        parent.mkdir(parents=True, exist_ok=True)
        if not parent.is_dir():
            raise SshTransportError("fetch destination parent is not a directory")
        final = parent / requested.name
        if final.is_symlink() or final.exists():
            raise SshTransportError("fetch destination must not exist or be a symlink")

        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{final.name}.",
            suffix=".fetch",
            dir=parent,
        )
        os.close(descriptor)
        temporary = Path(temporary_name)
        try:
            completed = subprocess.run(
                [
                    "scp",
                    "-o", "BatchMode=yes",
                    "-o", "IdentitiesOnly=yes",
                    "-o", "StrictHostKeyChecking=yes",
                    "-o", f"UserKnownHostsFile={self.known_hosts}",
                    "-o", f"ConnectTimeout={self.connect_timeout_seconds}",
                    "-i", str(self.identity_file),
                    f"{target.user}@{target.address}:{source}",
                    str(temporary),
                ],
                text=True,
                capture_output=True,
                timeout=timeout_seconds,
                check=False,
                env={**os.environ, "LC_ALL": "C"},
            )
            if completed.returncode != 0:
                raise SshTransportError(
                    f"{target.node_id}: "
                    f"{completed.stderr.strip() or 'secure fetch failed'}"
                )
            metadata = temporary.lstat()
            if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
                raise SshTransportError("fetched object is not a single-link regular file")
            if metadata.st_size <= 0 or metadata.st_size > max_bytes:
                raise SshTransportError(
                    f"fetched file size must be between 1 and {max_bytes} bytes"
                )
            os.chmod(temporary, 0o640)
            with temporary.open("rb") as stream:
                os.fsync(stream.fileno())
            try:
                os.link(temporary, final, follow_symlinks=False)
            except FileExistsError as exc:
                raise SshTransportError(
                    "fetch destination appeared during transfer"
                ) from exc
            return metadata.st_size
        finally:
            temporary.unlink(missing_ok=True)


def scan_host_key(address: str, output: Path, *, port: int = 22) -> None:
    """Enrollment helper. A human must compare the fingerprint in provider console."""
    completed = subprocess.run(
        ["ssh-keyscan", "-T", "10", "-p", str(port), address],
        text=True,
        capture_output=True,
        timeout=15,
        check=False,
    )
    if completed.returncode != 0 or not completed.stdout.strip():
        raise SshTransportError(f"could not scan host key for {address}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("a", encoding="utf-8") as handle:
        handle.write(completed.stdout)
