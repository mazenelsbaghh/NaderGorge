from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HOSTS = {
    "massar-academy.net",
    "app.massar-academy.net",
    "admin.massar-academy.net",
    "teacher.massar-academy.net",
    "staff.massar-academy.net",
    "api.massar-academy.net",
    "ws.massar-academy.net",
    "assets.massar-academy.net",
}


def test_every_node_runs_the_complete_application_stack() -> None:
    compose = (ROOT / "deploy/production/compose/compose.app.yml").read_text()
    for service in (
        "backend",
        "worker",
        "landing",
        "student",
        "admin",
        "teacher",
        "staff",
        "gateway",
    ):
        assert f"  {service}:\n" in compose
    assert "\n  db:\n" not in compose
    assert "\n  redis:\n" not in compose
    assert "subnet: 172.29.0.0/24" in compose


def test_haproxy_balances_every_approved_host_across_three_nodes() -> None:
    config = (ROOT / "deploy/production/config/haproxy/postgres.cfg").read_text()
    for host in HOSTS:
        assert host in config
    assert "http-request deny deny_status 421 unless approved_host" in config
    app_backend = config.split("backend massar_nodes", 1)[1]
    assert "balance roundrobin" in app_backend
    assert app_backend.count(":8080 check") == 3


def test_node_gateway_has_exact_surface_routes_and_private_asset_denials() -> None:
    config = (
        ROOT / "deploy/production/config/nginx/massar-node.conf.template"
    ).read_text()
    configured = {
        line.split("server_name", 1)[1].strip(" ;")
        for line in config.splitlines()
        if line.strip().startswith("server_name ")
    }
    assert HOSTS <= configured
    assert "location ^~ /protected/ { return 404; }" in config
    assert "location ^~ /private/ { return 404; }" in config
    assert "proxy_set_header Upgrade $http_upgrade;" in config
